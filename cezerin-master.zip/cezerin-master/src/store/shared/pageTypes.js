export const PAGE = 'page';
export const PRODUCT_CATEGORY = 'product-category';
export const PRODUCT = 'product';
export const RESERVED = 'reserved';
export const SEARCH = 'search';
