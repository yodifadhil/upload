<?php
// Sienna Theme Functions File

// Include Files
require_once get_template_directory().'/inc/template-tags.php';
require_once get_template_directory().'/inc/theme-options.php';
require_once get_template_directory().'/inc/class-tgm-plugin-activation.php';

// Theme Setup Stage 1

if ( ! function_exists( 'sienna_setup' ) ) :

	function sienna_setup() {

		// Make theme available for translation
		load_theme_textdomain( 'sienna', get_template_directory() . '/languages' );

		// Add required theme supports
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'custom-background' );

		// Add editor style
		add_editor_style( get_stylesheet_uri() );

	}

endif;
add_action( 'after_setup_theme', 'sienna_setup' );

// Theme Setup Stage 2

	// Set Content Width
	function sienna_content_width() {
		$GLOBALS['content_width'] = apply_filters( 'sienna_content_width', 960 );
	}
	add_action( 'after_setup_theme', 'sienna_content_width', 0 );

	// Register Widgets
	function sienna_widgets_init() {

		register_sidebar( array(
			'name'          => esc_html__( 'Sidebar', 'sienna' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Default Sidebar', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		register_sidebar( array(
			'name'          => esc_html__( 'Shop', 'sienna' ),
			'id'            => 'shop',
			'description'   => esc_html__( 'Shop Sidebar', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		register_sidebar( array(
			'name'          => esc_html__( 'Footer Area 1', 'sienna' ),
			'id'            => 'footer-area-1',
			'description'   => esc_html__( 'Footer Sidebar 1', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

	register_sidebar( array(
			'name'          => esc_html__( 'Footer Area 2', 'sienna' ),
			'id'            => 'footer-area-2',
			'description'   => esc_html__( 'Footer Sidebar 2', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

	register_sidebar( array(
			'name'          => esc_html__( 'Footer Area 3', 'sienna' ),
			'id'            => 'footer-area-3',
			'description'   => esc_html__( 'Footer Sidebar 3', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

	register_sidebar( array(
			'name'          => esc_html__( 'Footer Area 4', 'sienna' ),
			'id'            => 'footer-area-4',
			'description'   => esc_html__( 'Footer Sidebar 4', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

	register_sidebar( array(
			'name'          => esc_html__( 'Footer Area 5', 'sienna' ),
			'id'            => 'footer-area-5',
			'description'   => 'The sidebar for footer column 5',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

	register_sidebar( array(
			'name'          => esc_html__( 'Footer Area 6', 'sienna' ),
			'id'            => 'footer-area-6',
			'description'   => esc_html__( 'Footer Sidebar 6', 'sienna' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

	}
	add_action( 'widgets_init', 'sienna_widgets_init' );

	// Register Menus
	function sienna_register_menus() {
		  register_nav_menu( 'top-left-menu', __( 'Top Left Menu', 'sienna' ) );
		  register_nav_menu( 'top-right-menu', __( 'Top Right Menu', 'sienna' ) );
		  register_nav_menu( 'footer-menu', __( 'Footer Menu', 'sienna' ) );
		}
	add_action( 'after_setup_theme', 'sienna_register_menus' );

	// Enqueue JS & CSS
	function sienna_scripts() {

		wp_enqueue_style( 'sienna-reset-css', get_template_directory_uri() . '/css/reset.css' );
		wp_enqueue_style( 'sienna-master-css', get_template_directory_uri() . '/css/master.css' );
		wp_enqueue_style( 'sienna-ie-css', get_template_directory_uri() . '/css/ie.css' );
		wp_enqueue_style( 'sienna-theme-css', get_template_directory_uri() . '/css/theme.css' );
		wp_enqueue_style( 'sienna-fonts', sienna_fonts_url(), array(), null );

		wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), false );

		if ( get_theme_mod( 'select_blog_layout' ) == 'left') {
			wp_enqueue_style( 'sienna-left-sidebar-css', get_template_directory_uri() . '/css/layouts/left-sidebar.css' );
		} else if ( get_theme_mod( 'select_blog_layout' ) == 'right') {
			wp_enqueue_style( 'sienna-right-sidebar-css', get_template_directory_uri() . '/css/layouts/right-sidebar.css' );
		} else if ( get_theme_mod( 'select_blog_layout' ) == 'none') {
			wp_enqueue_style( 'sienna-no-sidebar-css', get_template_directory_uri() . '/css/layouts/no-sidebar.css' );
		} else {
			wp_enqueue_style( 'sienna-left-sidebar-css', get_template_directory_uri() . '/css/layouts/left-sidebar.css' );
		}

		if ( get_theme_mod( 'select_shop_layout' ) == 'left') {
			wp_enqueue_style( 'sienna-shop-left-sidebar-css', get_template_directory_uri() . '/css/layouts/shop-left-sidebar.css' );
		} else if ( get_theme_mod( 'select_shop_layout' ) == 'right') {
			wp_enqueue_style( 'sienna-shop-right-sidebar-css', get_template_directory_uri() . '/css/layouts/shop-right-sidebar.css' );
		} else if ( get_theme_mod( 'select_shop_layout' ) == 'none') {
			wp_enqueue_style( 'sienna-shop-no-sidebar-css', get_template_directory_uri() . '/css/layouts/shop-no-sidebar.css' );
		} else {
			wp_enqueue_style( 'sienna-shop-left-sidebar-css', get_template_directory_uri() . '/css/layouts/shop-left-sidebar.css' );
		}


		// This section is for the demo only. If you are seeing this you can safely remove this part.

			if ( class_exists( 'WooCommerce' ) ) {
				if ( is_product_category( 'boots' ) ) {
					wp_enqueue_style( 'sienna-shop-left-sidebar-css', get_template_directory_uri() . '/css/layouts/shop-left-sidebar.css' );
				}

				if ( is_product_category( 'footwear' ) ) {
					wp_enqueue_style( 'sienna-shop-no-sidebar-css', get_template_directory_uri() . '/css/layouts/shop-no-sidebar.css' );
				}
			}

		// End of demo section.


		if ( get_theme_mod( 'select_smoothscrolling' ) == 'on') {
			wp_enqueue_script( 'sienna-smooth-scrolling', get_template_directory_uri() . '/js/smoothscrolling.js', array(), '', true );
		}

		wp_enqueue_script( 'retina-js', get_template_directory_uri() . '/js/retina.js', array(), '', false );
		wp_enqueue_script( 'sienna-theme-js', get_template_directory_uri() . '/js/theme.js', array('jquery'), '', false );


		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}

	add_action( 'wp_enqueue_scripts', 'sienna_scripts' );


	// Add Woocommerce Support
	if ( class_exists( 'WooCommerce' ) ) {
		function sienna_woocommerce_support() {
	    	add_theme_support( 'woocommerce' );
		}
		add_action( 'after_setup_theme', 'sienna_woocommerce_support' );
	}

	//* Customize [...] in WordPress excerpts
	function sienna_read_more_custom_excerpt( $text ) {
	   if ( strpos( $text, '[&hellip;]') ) {
	      $excerpt = str_replace( '[&hellip;]', '...', $text );
	   } else {
	      $excerpt = $text . '...';
	   }
	   return $excerpt;
	}
	add_filter( 'the_excerpt', 'sienna_read_more_custom_excerpt' );

	// Show Wishlist Link
	if (class_exists('YITH_WCWL')) {

	add_action('woocommerce_after_shop_loop_item', 'show_add_to_wishlist', 50 );
		function show_add_to_wishlist()
		{
		  echo do_shortcode('[yith_wcwl_add_to_wishlist]');
		}

		} else {}

	// Setup TGM Plugin Recommendations
	function sienna_register_required_plugins() {

	    $plugins = array(

			array(
	            'name'          => 'Visual Composer',
	            'slug'          => 'js_composer',
	            'source'        => esc_url('http://demo.elusivethemes.com/plugins/js_composer.zip'),
	            'required'          => true,
	            'force_activation'      => false,
	            'force_deactivation'    => false,
	        ),

			array(
	            'name'          => esc_html__( 'Slider Revolution'),
	            'slug'          => 'revslider',
	            'source'            => esc_url('http://demo.elusivethemes.com/plugins/revslider.zip'),
	            'required'          => false,
	            'force_activation'      => false,
	            'force_deactivation'    => false,
	        ),

	        array(
	            'name'          => esc_html__( 'Woo Filter'),
	            'slug'          => 'ct-woofiltering',
	            'source'            => esc_url('http://demo.elusivethemes.com/plugins/ct-woofiltering.zip'),
	            'required'          => false,
	            'force_activation'      => false,
	            'force_deactivation'    => false,
	        ),

			array(
	            'name'          => esc_html__( 'Woocommerce'),
	            'slug'          => 'woocommerce',
	            'required'          => false,
	        ),

	        array(
				'name'      => esc_html__( 'add to cart popup'),
				'slug'      => 'woocommerce-woocart-popup-lite',
				'required'  => false,
			),

			array(
				'name'      => esc_html__( 'YITH quick view'),
				'slug'      => 'yith-woocommerce-quick-view',
				'required'  => false,
			),

			array(
				'name'      => esc_html__( 'YITH wishlist'),
				'slug'      => 'yith-woocommerce-wishlist',
				'required'  => false,
			),

			array(
				'name'      => esc_html__( 'Woo image zoom'),
				'slug'      => 'woocommerce-image-zoom',
				'required'  => false,
			),

			array(
				'name'      => esc_html__( 'Woo image flipper'),
				'slug'      => 'woocommerce-product-image-flipper',
				'required'  => false,
			),

			array(
				'name'      => esc_html__( 'Easy Google Fonts'),
				'slug'      => 'easy-google-fonts',
				'required'  => false,
			),

			array(
				'name'      => esc_html__( 'Contact Form 7'),
				'slug'      => 'contact-form-7',
				'required'  => false,
			),

		);

	    $theme_text_domain = 'sienna';

	    $config = array(
	        'default_path' => '',
	        'menu'         => 'tgmpa-install-plugins',
	        'has_notices'  => true,
	        'dismissable'  => true,
	        'dismiss_msg'  => '',
	        'is_automatic' => true,
	        'message'      => '',
	        'strings'      => array(
	            'page_title'                      => esc_html__( 'Install Required Plugins', 'sienna' ),
	            'menu_title'                      => esc_html__( 'Install Plugins', 'sienna' ),
	            'installing'                      => esc_html__( 'Installing Plugin: %s', 'sienna' ), // %s = plugin name.
	            'oops'                            => esc_html__( 'Something went wrong with the plugin API.', 'sienna' ),
	            'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'sienna'  ), // %1$s = plugin name(s).
	            'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'sienna'  ), // %1$s = plugin name(s).
	            'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'sienna'  ),
	            'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins', 'sienna'  ),
	            'return'                          => esc_html__( 'Return to Required Plugins Installer', 'sienna' ),
	            'plugin_activated'                => esc_html__( 'Plugin activated successfully.', 'sienna' ),
	            'complete'                        => esc_html__( 'All plugins installed and activated successfully. %s', 'sienna' ), // %s = dashboard link.
	            'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
	        )
	    );

	    tgmpa( $plugins, $config );

	}

	add_action( 'tgmpa_register', 'sienna_register_required_plugins' );

		// Update Header Cart Count
		if ( class_exists( 'WooCommerce' ) ) {
			add_filter( 'woocommerce_add_to_cart_fragments', 'sienna_woocommerce_header_add_to_cart_fragment' );
			function sienna_woocommerce_header_add_to_cart_fragment( $fragments ) {
				ob_start();
				?>
				<a class="cart-contents" href="<?php echo WC()->cart->get_cart_url(); ?>" title="<?php esc_html_e( 'View your shopping cart', 'sienna' ); ?>">
			                        <div class="header-cart-icon-wrapper">
			                            <div class="header-cart-icon"></div>
			                            <div class="cart-counter"><?php echo WC()->cart->cart_contents_count; ?></div>
			                        </div>
			    </a>
				<?php

				$fragments['a.cart-contents'] = ob_get_clean();
				return $fragments;
			}
		}

		// Add Google Fonts
		function sienna_fonts_url() {
		    $font_url = '';

		    /*
		    Translators: If there are characters in your language that are not supported
		    by chosen font(s), translate this to 'off'. Do not translate into your own language.
		     */
		    if ( 'off' !== _x( 'on', 'Google font: on or off', 'studio' ) ) {
		        $font_url = add_query_arg( 'family', urlencode( 'Questrial|Open Sans:400,600,700|Playfair Display:400,700&subset=latin,latin-ext' ), "//fonts.googleapis.com/css" );
		    }
		    return $font_url;
		}

		function sienna_font_scripts() {
		    wp_enqueue_style( 'sienna-fonts', sienna_fonts_url(), array(), '1.0.0' );
		}
		add_action( 'wp_enqueue_scripts', 'sienna_font_scripts' );

?>
