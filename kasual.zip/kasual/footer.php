    <div class="clearfix"></div>

        </div>

		<!-- Start of Footer -->
	    <footer id="colophon" class="site-footer">
			<div class="footer-col-container">
				<div class="footer-row">
					<div class="footer-col left" >
					<?php if ( is_active_sidebar( 'footer-area-1' ) ) {
								dynamic_sidebar( 'footer-area-1' );
							} else {
								sienna_display_logo();
								}
					?>
				</div>
        <?php if ( is_active_sidebar( 'footer-area-2' ) ) { ?>
					<div class="footer-col center" ><?php dynamic_sidebar( 'footer-area-2' ); ?></div>
          <?php } ?>
          <?php if ( is_active_sidebar( 'footer-area-3' ) ) { ?>
					<div class="footer-col right"><?php dynamic_sidebar( 'footer-area-3' ); ?></div>
          <?php } ?>
				</div>

				<div class="footer-row bottom">
          <?php if ( is_active_sidebar( 'footer-area-4' ) ) { ?>
					<div class="footer-col left"><?php dynamic_sidebar( 'footer-area-4' ); ?></div>
          <?php } ?>
          <?php if ( is_active_sidebar( 'footer-area-5' ) ) { ?>
					<div class="footer-col center" ><?php dynamic_sidebar( 'footer-area-5' ); ?></div>
          <?php } ?>
          <?php if ( is_active_sidebar( 'footer-area-6' ) ) { ?>
					<div class="footer-col right"><?php dynamic_sidebar( 'footer-area-6' ); ?></div>
          <?php } ?>
				</div>
			</div>
		</footer><!-- #colophon -->

    <?php wp_footer(); ?>

</body>
</html>
