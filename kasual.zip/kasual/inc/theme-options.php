<?php

function sienna_customizer( $wp_customize ) {

	// Remove Unwanted Default Sections
	$wp_customize->remove_control("header_image");
	$wp_customize->remove_control("display_header_text");
	$wp_customize->remove_section("background_image");
	$wp_customize->remove_section("colors");

	// Add Sections
    $wp_customize->add_section(
        'general_section',
        	array(
	            'title' => 'Theme Settings',
	            'description' => 'The themes general settings section.',
	            'priority' => 1,
        	)
    );

    $wp_customize->add_section(
        'colors_section',
        	array(
	            'title' => 'Colors',
	            'description' => 'The themes color settings section.',
	            'priority' => 36,
        	)
    );

    // Add Settings & Controls
    $wp_customize->add_setting(
	    'select_smoothscrolling',
	    	array(
	        	'default' => 'on',
	        	'sanitize_callback' => 'sienna_sanitize_text',
	    )
	);

	$wp_customize->add_control(
		'select_smoothscrolling',
			array(
			'label' => esc_html__( 'Smooth Scrolling Effect', 'sienna' ),
			'section' => 'general_section',
			'settings' => 'select_smoothscrolling',
			'type' => 'radio',
			'choices' => array(
				'on' => 'On',
				'off' => 'Off',

			),
	) );

    $wp_customize->add_setting(
	    'select_shop_layout',
	    	array(
	        	'default' => 'right',
	        	'sanitize_callback' => 'sienna_sanitize_text',
	    )
	);

	$wp_customize->add_control(
		'select_shop_layout',
			array(
				'label' => esc_html__( 'Shop Sidebar Position', 'sienna' ),
				'section' => 'general_section',
				'settings' => 'select_shop_layout',
				'type' => 'radio',
				'choices' => array(
					'left' => 'Left',
					'right' => 'Right',
					'none' => 'None',
			),
	) );

	$wp_customize->add_setting(
	    'select_blog_layout',
	    	array(
	        	'default' => 'right',
	        	'sanitize_callback' => 'sienna_sanitize_text',
	    	)
	);

	$wp_customize->add_control(
		'select_blog_layout',
			array(
				'label' => esc_html__( 'Blog Sidebar Position', 'sienna' ),
				'section' => 'general_section',
				'settings' => 'select_blog_layout',
				'type' => 'radio',
				'choices' => array(
					'left' => 'Left',
					'right' => 'Right',
					'none' => 'None',
				),
			) );

	$wp_customize->add_setting(
	    'sienna_logo',
	    	array(
	        	'sanitize_callback' => 'esc_url_raw',
	    	)
	);

	$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize, 'sienna_logo',
			array(
				esc_html__( 'Upload Logo', 'sienna' ),
				'section' => 'title_tagline',
				'settings' => 'sienna_logo',
			) ) );

	$wp_customize->add_setting(
        'sienna_secondary_color',
        array(
            'default'     => '#9D8980',
            'sanitize_callback' => 'sienna_sanitize_text',
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'secondary_color',
            array(
                'label'      => esc_html__( 'Accent Color', 'sienna' ),
                'section'    => 'colors_section',
                'settings'   => 'sienna_secondary_color'
            )
        )
    );

}

add_action( 'customize_register', 'sienna_customizer' );

// Theme Option Functions
	function sienna_sanitize_text( $str ) {
		return sanitize_text_field( $str );
	}

	function sienna_sanitize_textarea( $text ) {
		return esc_textarea( $text );
	}

	function sienna_sanitize_number( $int ) {
		return absint( $int );
	}

	function sienna_sanitize_email( $email ) {
		if(is_email( $email )){
		    return $email;
		}else{
		    return '';
		}
	}

// Add Styling
function sienna_customizer_css() {
    ?>
    <style type="text/css">

        button:hover,
		input[type="button"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.woocommerce #respond input#submit.alt:hover,
		.woocommerce a.button.alt:hover,
		.woocommerce button.button.alt:hover,
		.woocommerce input.button.alt:hover,
		.woocommerce #respond input#submit:hover,
		.woocommerce a.button:hover,
		.woocommerce button.button:hover,
		.woocommerce input.button:hover,
		.theme-button:hover,
		.btn .btn-flat:hover,
		.entry-footer a:hover,
		.cart-counter,
		.custom .tp-bullet:hover,
		.custom .tp-bullet.selected,
		.page-navigation li a:hover,
		.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
		.sienna-button a:hover {
			background: <?php echo get_theme_mod( 'sienna_secondary_color' ); ?>!important;
		}

		blockquote {
		    border-left: 10px solid <?php echo get_theme_mod( 'sienna_secondary_color' ); ?>;
		}

    </style>
    <?php
}
add_action( 'wp_head', 'sienna_customizer_css' );
?>
