<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <!-- Start of Container -->
    <div class="preloader"></div>

    <!-- Start of Container -->
    <div class="container">

        <!-- Mobile Menu -->
        <div class="mobile-menu menu-overlay hidden">
              <div class="scroller">
                    <div class="header-search-icon"></div>
                    <div class="closeicon small"></div>
                    <h3 class="mobile-menu-header">Main Menu</h3>
                    <?php wp_nav_menu( array( 'theme_location' => 'top-left-menu' ) ); ?>
                    <?php wp_nav_menu( array( 'theme_location' => 'top-right-menu' ) ); ?>
              </div>
        </div>

        <!-- Start of Header -->
            <header class="site-header">

                <div class="header-left-block">

                    <nav class="main-navigation">
                        <?php wp_nav_menu( array( 'theme_location' => 'top-left-menu' ) ); ?>
                    </nav>

                </div>

                <div class="header-center-block">

                    <div class="site-logo">
                        <?php sienna_display_logo(); ?>
                    </div>

                </div>

                <div class="header-right-block">

                    <nav class="main-navigation">
                        <?php wp_nav_menu( array( 'theme_location' => 'top-right-menu' ) ); ?>
                    </nav>

                    <?php if ( class_exists( 'WooCommerce' ) ) { ?>

                        <a class="cart-contents" href="<?php echo WC()->cart->get_cart_url(); ?>" title="<?php esc_html_e( 'View your shopping cart', 'sienna' ); ?>">

                            <div class="header-cart-icon-wrapper">
                                <div class="header-cart-icon"></div>
                                <div class="cart-counter"><?php echo WC()->cart->cart_contents_count; ?></div>
                            </div>

                        </a>

                    <?php } ?>

                    <div class="header-search-icon"></div>

                </div>

                <div class="mobile-menu-icon"></div>

            </header>

        <div class="clearfix"></div>

        <!-- Start of Search Overlay -->
        <div class="search-menu search-overlay hidden">
            <div class="closeicon"></div>
            <?php get_search_form(); ?>
        </div>
