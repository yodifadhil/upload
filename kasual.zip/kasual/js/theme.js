// Custom Javascript

// Preloader

(function($) {
    "use strict";

    $(window).load(function() {
          $('.preloader').fadeOut(1000);

          $('.header-search-icon').on('click', function(e) {
            $('.search-overlay').removeClass("hidden");
          });

          $('.mobile-menu-icon').on('click', function(e) {
            $('.menu-overlay').removeClass("hidden");
          });

          $('.closeicon').on('click', function(e) {
            $('.search-overlay').addClass("hidden");
            $('.menu-overlay').addClass("hidden");
          });

          $('.menu-item-has-children').on('click', function(event) {
            event.preventDefault();
            $(this).children('ul').toggleClass('show-submenu');
            return false;
          });

          $(".menu li a, .post-navigation a").on('click', function(event) {
            event.preventDefault();
            var linkLocation = this.href;
            console.log(linkLocation);
            if (linkLocation.indexOf('#') >= 0) {} else {
                setTimeout(function() {
                    $('.preloader').fadeIn(300);
                    window.location = linkLocation;
                }, 0);
            }
        });
    });

})(jQuery);

// Misc FX

(function($) {
    "use strict";

    $(window).load(function() {

        var lastScrollTop = 0, delta = 5;
        $(window).scroll(function(){
        var nowScrollTop = $(this).scrollTop();
        if(Math.abs(lastScrollTop - nowScrollTop) >= delta){
        if (nowScrollTop > lastScrollTop){

        $('.site-header').addClass('hidden');
        } else {

        $('.site-header').removeClass('hidden');
        }
        lastScrollTop = nowScrollTop;
        }
        });

        $( ".widget" ).wrapInner( "<div class='widget-inner'></div>");
        $( "#sidebar-area .widget-title" ).wrap( "<div class='widget-header-wrapper'></div>");
        $(".search-overlay .s").attr("placeholder", "Type here to search");

    });

})(jQuery);


// Scroll Speed fx

(function($) {
    "use strict";

    $(function(){
        var boxes = $('[data-scroll-speed]'),
            $window = $(window);
        $window.on('scroll', function(){
          var scrollTop = $window.scrollTop();
          boxes.each(function(){
            var $this = $(this),
                scrollspeed = parseInt($this.data('scroll-speed')),
                val = - scrollTop / scrollspeed;
            $this.css('transform', 'translateY(' + val + 'px)');
            //$('.cont').height('.cont' - 100);
           });
  });
})
})(jQuery);



// Product Counters

(function($) {
    "use strict";
    $(window).load(function() {

(function() {

  $(".qty").before("<span class=\"input-number-decrement\">–</span>");
  $(".qty").after("<span class=\"input-number-increment\">+</span>");

  window.inputNumber = function(el) {

    var min = el.attr('min') || false;
    var max = el.attr('max') || false;

    var els = {};

    els.dec = el.prev();
    els.inc = el.next();

    el.each(function() {
      init($(this));
    });

    function init(el) {

      el.prev().on('click', decrement);
      el.next().on('click', increment);

      function decrement() {
        var value = el[0].value;
        value--;
        if(!min || value >= min) {
          el[0].value = value;
        }
      }

      function increment() {
        var value = el[0].value;
        value++;
        if(!max || value <= max) {
          el[0].value = value++;
        }
      }
    }
  }
})();

inputNumber($('.qty'));
});

})(jQuery);


// Product Box Icons

(function($) {
    "use strict";

    $(window).load(function() {
      $( "h2" ).wrapInner( "<span></span>");
      $( ".zoom" ).wrapInner( '<div class="zoom-wrapper"></div>');
      $( "ul.products .wp-post-image" ).wrap( "<div class='product-wrapper'></div>");
      $( "ul.products .wp-post-image" ).before( "<div class='coverup'></div><div class='product-icons-container'><div class='col1' data-tooltip='Quickview'></div><div class='col2' data-tooltip='Add to Cart'></div><div class='col3' data-tooltip='Add to Wishlist'></div></div>");
    });

})(jQuery);

(function($) {
    "use strict";
     $(window).load(function() {

       $('.product-icons-container .col1').on('click', function(e) {
          e.preventDefault();
          $(this).parent().parent().parent().parent().find(".yith-wcqv-button").click();
        });

       $('.product-icons-container .col2').on('click', function(e) {
          if(!$(this).parent().parent().parent().parent().find(".add_to_cart_button").hasClass('product_type_variable')) {
            e.preventDefault();
          }
          $(this).parent().parent().parent().parent().find(".add_to_cart_button").click();
        });

       $('.product-icons-container .col3').on('click', function(e) {
          e.preventDefault();
          $(this).parent().parent().parent().parent().find(".add_to_wishlist").click();
        });

    });
})(jQuery);
